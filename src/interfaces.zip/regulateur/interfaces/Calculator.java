package regulateur.interfaces;

public interface Calculator {
    //Need to find how to implement location as GPS data
    float calcTargetSpeed(float speed, float limit, int location);

    float calcAccel(float targetSpeed, float actualSpeed);
}
