package environement.interfaces;

import gps.interfaces.CoordsGPS;

public interface Environement {
    int getLimit(CoordsGPS position);
}
