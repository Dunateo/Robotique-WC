package gps.interfaces;

abstract public class Coordinate {
    private float deg;
    private float min;
    private float sec;
}
