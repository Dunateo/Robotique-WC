package gps.interfaces;

abstract public class CoordsGPS {
    Coordinate longitude;
    Coordinate latitude;
}
