package gps.interfaces;

public interface ModuleGPS {
    CoordsGPS getPosition();
}
