package command.interfaces;

public interface AccelManager {
    int acceleration(int speed);
    int deceleration(int speed);
}
