package carto.interfaces;

import gps.interfaces.CoordsGPS;

public interface Cartograph {
    int getLimit(CoordsGPS position);
}
