package userinterface.interfaces;

public interface UserInterface {
}
