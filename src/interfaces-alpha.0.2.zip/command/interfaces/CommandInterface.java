package command.interfaces;

public interface CommandInterface {
    int getVitesseReelle();
}
