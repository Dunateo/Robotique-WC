package gps.interfaces;

public interface ModuleGPS {

}
