package environement.interfaces;

public interface Environement {

}
