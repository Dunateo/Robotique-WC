package carto.interfaces;

public interface Cartograph {
}
