package regulateur.implementations;

import regulateur.interfaces.Manager;
import regulateur.interfaces.Calculator;

public class Regulator{

}
